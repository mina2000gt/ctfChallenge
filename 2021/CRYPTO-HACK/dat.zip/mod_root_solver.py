def gcd(a, b):
    while b: a, b = b, a % b
    return a
def isPrimeMR(n):
    d = n - 1
    d = d // (d & -d)
    L = [2, 7, 61] if n < 1<<32 else [2, 3, 5, 7, 11, 13, 17] if n < 1<<48 else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    for a in L:
        t = d
        y = pow(a, t, n)
        if y == 1: continue
        while y != n - 1:
            y = y * y % n
            if y == 1 or t == n - 1: return 0
            t <<= 1
    return 1
def findFactorRho(n):
    m = 1 << n.bit_length() // 8
    for c in range(1, 99):
        f = lambda x: (x * x + c) % n
        y, r, q, g = 2, 1, 1, 1
        while g == 1:
            x = y
            for i in range(r):
                y = f(y)
            k = 0
            while k < r and g == 1:
                ys = y
                for i in range(min(m, r - k)):
                    y = f(y)
                    q = q * abs(x - y) % n
                g = gcd(q, n)
                k += m
            r <<= 1
        if g == n:
            g = 1
            while g == 1:
                ys = f(ys)
                g = gcd(abs(x - ys), n)
        if g < n:
            if isPrimeMR(g): return g
            elif isPrimeMR(n // g): return n // g
            return findFactorRho(g)
def primeFactor(n):
    i = 2
    ret = {}
    rhoFlg = 0
    while i * i <= n:
        k = 0
        while n % i == 0:
            n //= i
            k += 1
        if k: ret[i] = k
        i += i % 2 + (3 if i % 3 == 1 else 1)
        if i == 101 and n >= 2 ** 20:
            while n > 1:
                if isPrimeMR(n):
                    ret[n], n = 1, 1
                else:
                    rhoFlg = 1
                    j = findFactorRho(n)
                    k = 0
                    while n % j == 0:
                        n //= j
                        k += 1
                    ret[j] = k

    if n > 1: ret[n] = 1
    if rhoFlg: ret = {x: ret[x] for x in sorted(ret)}
    return ret

def inv(a, mod):
    b = mod
    s, u = 1, 0
    while b:
        q = a // b
        a, b = b, a % b
        s, u = u, s - q * u
    assert a == 1
    return s % mod

def sqrt_mod_prime_power(a, p, e, mod): # solve x^(p^e) = a
    q = mod - 1
    s = 0
    while q % p == 0:
        q //= p
        s += 1
    pe = p ** e
    d = pow(-q, (p-1) * p ** (e-1) - 1, pe) * q
    r = pow(a, (d + 1) // pe, mod)
    t = pow(a, d, mod)
    if t == 1: return r
    ps = p ** (s - 1)
    c = -1
    z = 2
    while 1:
        c = pow(z, q, mod)
        if pow(c, ps, mod) != 1:
            break
        z += 1
    b = -1
    while t != 1:
        tmp = pow(t, p, mod)
        s2 = 1
        while tmp != 1:
            tmp = pow(tmp, p, mod)
            s2 += 1
        if s2 + e <= s:
            b = c
            for _ in range(s - s2 - e):
                b = pow(b, p, mod)
            c = pow(b, pe, mod)
            s = s2
        r = r * b % mod
        t = t * c % mod
    return r

def sqrt_mod(a, n, p): # solve x^n = a (mod p)
    assert n >= 1
    a %= p
    n %= p - 1
    if a <= 1: return a
    g = gcd(p - 1, n)
    if pow(a, (p-1) // g, p) != 1:
        return -1
    a = pow(a, inv(n // g, (p-1) // g), p)
    pf = primeFactor(g)
    for pp in pf:
        a = sqrt_mod_prime_power(a, pp, pf[pp], p)
    return a