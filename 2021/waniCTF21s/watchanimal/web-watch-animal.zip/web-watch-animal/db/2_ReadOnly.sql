REVOKE all privileges ON animaldb.* FROM animal;
GRANT SELECT ON animaldb.* TO animal;